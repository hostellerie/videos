<?php

require_once '../lib-common.php';

$seo = new Videos_Seo(
    $_CONF['site_url'],
    isset($_CONF['site_name']) ? $_CONF['site_name'] : '',
    $_VIDEOS_CONF
);

if (empty($_VIDEOS_CONF['enabled'])) {
    $publicTitle = VIDEOS_getPublicTitle();
    echo COM_createHTMLDocument(
        COM_showMessageText($LANG_VIDEOS['catalogue_disabled'], '', true),
        array(
            'pagetitle' => $publicTitle,
            'headercode' => $seo->catalogue($publicTitle, 1, false)
        )
    );
    exit;
}

$publicTitle = VIDEOS_getPublicTitle();
$bootstrap = new Videos_Bootstrap($_CONF);
$videos = array();
$videoMetadata = array();
$catalogueContextKey = '';
$message = '';
$searchQuery = isset($_GET['q'])
    ? trim(strip_tags((string) $_GET['q'])) : '';
if (function_exists('MBYTE_substr')) {
    $searchQuery = MBYTE_substr($searchQuery, 0, 120);
} else {
    $searchQuery = substr($searchQuery, 0, 120);
}
$isLocalSearch = $searchQuery !== '';
$searchTotal = 0;
$page = isset($_GET['page']) ? max(1, (int) $_GET['page']) : 1;
$perPage = isset($_VIDEOS_CONF['videos_per_page'])
    ? max(1, min(50, (int) $_VIDEOS_CONF['videos_per_page'])) : 12;
$pageCount = 1;

if (!$bootstrap->isReady()) {
    $message = $LANG_VIDEOS['catalogue_unavailable'];
} elseif ($isLocalSearch) {
    // Reuse exactly the same bounded local corpus as Geeklog Search API 2.
    // No YouTube API call is performed by a visitor search.
    $searchService = VIDEOS_getSearchService($bootstrap);
    if ($searchService === false) {
        $message = $LANG_VIDEOS['catalogue_search_unavailable'];
    } else {
        $matches = $searchService->search(
            $searchQuery,
            'any',
            '',
            '',
            false,
            500
        );
        $allVideos = array();
        foreach ($matches as $videoId => $match) {
            if (!empty($match['video']) && is_array($match['video'])) {
                $allVideos[$videoId] = $match['video'];
            }
            if (!empty($match['ranking']) && is_array($match['ranking'])) {
                $videoMetadata[$videoId] = array(
                    'rating_count' => isset($match['ranking']['rating_count'])
                        ? $match['ranking']['rating_count'] : 0,
                    'rating_average' => isset($match['ranking']['rating_average'])
                        ? $match['ranking']['rating_average'] : 0
                );
            }
        }
        $searchTotal = count($allVideos);
        $pageCount = max(1, (int) ceil($searchTotal / $perPage));
        $page = min($page, $pageCount);
        $videos = array_slice(
            $allVideos,
            ($page - 1) * $perPage,
            $perPage,
            true
        );
        if ($searchTotal === 0) {
            $message = $LANG_VIDEOS['catalogue_search_empty'];
        }
    }
} else {
    $extractor = new Videos_KeywordExtractor(
        isset($_VIDEOS_CONF['additional_stop_words'])
            ? $_VIDEOS_CONF['additional_stop_words'] : ''
    );
    $context = array(
        'site_title' => isset($_CONF['site_name']) ? $_CONF['site_name'] : '',
        'site_description' => isset($_CONF['site_slogan'])
            ? $_CONF['site_slogan'] : '',
        'page_title' => '',
        'page_description' => '',
        'meta_keywords' => '',
        'content' => ''
    );
    $analysis = array(
        'mode' => isset($_VIDEOS_CONF['analysis_mode'])
            ? $_VIDEOS_CONF['analysis_mode'] : 'mixed',
        'maximum' => isset($_VIDEOS_CONF['max_keywords'])
            ? $_VIDEOS_CONF['max_keywords'] : 8,
        'title_weight' => isset($_VIDEOS_CONF['title_weight'])
            ? $_VIDEOS_CONF['title_weight'] : 5,
        'meta_weight' => isset($_VIDEOS_CONF['meta_weight'])
            ? $_VIDEOS_CONF['meta_weight'] : 4,
        'content_weight' => isset($_VIDEOS_CONF['content_weight'])
            ? $_VIDEOS_CONF['content_weight'] : 1,
        'manual_keywords' => isset($_VIDEOS_CONF['manual_keywords'])
            ? $_VIDEOS_CONF['manual_keywords'] : '',
        'required_keywords' => isset($_VIDEOS_CONF['required_keywords'])
            ? $_VIDEOS_CONF['required_keywords'] : '',
        'excluded_keywords' => isset($_VIDEOS_CONF['excluded_keywords'])
            ? $_VIDEOS_CONF['excluded_keywords'] : ''
    );
    $terms = $extractor->extract($context, $analysis);
    $query = $extractor->buildQuery($terms, $analysis['excluded_keywords']);
    if ($query === '') {
        $message = $LANG_VIDEOS['catalogue_topic_required'];
    } else {
        $result = videos_public_search($bootstrap, $query, $_VIDEOS_CONF);
        if ($result === false) {
            $message = $LANG_VIDEOS['catalogue_none_available'];
        } else {
            $catalogueContextKey = isset($result['cache_key']) &&
                preg_match('/^[a-f0-9]{64}$/', $result['cache_key'])
                ? $result['cache_key'] : '';
            $privacy = new Videos_Privacy(
                $bootstrap->getStore(),
                $bootstrap->getSecret()
            );
            $ratingStats = new Videos_RatingStats($bootstrap->getStore());
            $videoStats = new Videos_VideoStats($bootstrap->getStore());
            $cache = new Videos_Cache($bootstrap->getStore());
            if (!empty($_VIDEOS_CONF['discovery_enabled'])) {
                $reservoir = new Videos_DiscoveryReservoir(
                    $bootstrap->getStore(),
                    $cache
                );
                $reservoir->ingest($result['videos'], $query);
                $reservoirVideos = $reservoir->videos($_VIDEOS_CONF);
                if (count($reservoirVideos) > 0) {
                    $result['videos'] = $reservoirVideos;
                    $result['video_ids'] = array_keys($reservoirVideos);
                }
            }
            $ranking = new Videos_Ranking(
                $bootstrap->getStore(),
                $ratingStats,
                $videoStats,
                $cache
            );
            $selector = new Videos_CatalogueSelector(
                $ratingStats,
                $privacy,
                $ranking
            );
            $selectionConfiguration = $_VIDEOS_CONF;
            $moderation = new Videos_Moderation($bootstrap->getStore());
            $priorityIds = $moderation->getPriorityChannelIds(500);
            if (count($priorityIds) > 0) {
                $existingPriority = isset(
                    $selectionConfiguration['priority_channels']
                ) ? $selectionConfiguration['priority_channels'] : '';
                $selectionConfiguration['priority_channels'] = trim(
                    $existingPriority . ',' . implode(',', $priorityIds),
                    ','
                );
            }
            $selection = $selector->select(
                $result['videos'],
                $query,
                $selectionConfiguration,
                !empty($_VIDEOS_CONF['account_history_enabled']) &&
                    isset($_USER['uid']) ? (int) $_USER['uid'] : 1
            );
            if (!empty($_VIDEOS_CONF['permanent_pool_enabled'])) {
                $pool = new Videos_PermanentPool(
                    $bootstrap->getStore(),
                    $cache
                );
                $poolVideos = $pool->videos(
                    $ranking->getGlobal(500),
                    $_VIDEOS_CONF
                );
                $poolSelection = $selector->select(
                    $poolVideos,
                    'permanent-pool',
                    $selectionConfiguration,
                    !empty($_VIDEOS_CONF['account_history_enabled']) &&
                        isset($_USER['uid']) ? (int) $_USER['uid'] : 1
                );
                $selection = $pool->mergeSelections(
                    $selection,
                    $poolSelection,
                    $_VIDEOS_CONF
                );
            }
            $allVideos = $selection['videos'];
            $videoMetadata = $selection['metadata'];
            $totalVideos = count($allVideos);
            $pageCount = max(1, (int) ceil($totalVideos / $perPage));
            $page = min($page, $pageCount);
            $videos = array_slice(
                $allVideos,
                ($page - 1) * $perPage,
                $perPage,
                true
            );
            if ($totalVideos === 0) {
                $message = $LANG_VIDEOS['no_more_videos'];
            }
        }
    }
}

$faqService = new Videos_Faq($LANG_VIDEOS_FAQ, $_VIDEOS_CONF);
$faqItems = !$isLocalSearch &&
    !empty($_VIDEOS_CONF['faq_catalogue_enabled']) &&
    $page === 1 && count($videos) > 0
    ? $faqService->catalogue() : array();
$faqHtml = count($faqItems) > 0
    ? $faqService->render($faqItems, $LANG_VIDEOS['faq_title']) : '';
$catalogueRenderer = new Videos_CatalogueRenderer(
    $bootstrap,
    $_VIDEOS_CONF,
    $LANG_VIDEOS,
    $_CONF['site_url']
);
$html = $catalogueRenderer->render(
    $publicTitle,
    $videos,
    $videoMetadata,
    $catalogueContextKey,
    $isLocalSearch,
    $searchTotal,
    $searchQuery,
    $page,
    $pageCount,
    $message,
    $faqHtml
);

if ($isLocalSearch) {
    // Search-result URLs are useful to visitors but should not create an
    // unbounded family of indexable query pages.
    $catalogueHeader = '<link rel="canonical" href="'
        . htmlspecialchars(
            $_CONF['site_url'] . '/videos/index.php',
            ENT_QUOTES,
            'UTF-8'
        ) . '">' . "\n"
        . '<meta name="robots" content="noindex,follow">';
} else {
    $catalogueHeader = $seo->catalogue(
        $publicTitle,
        $page,
        count($videos) > 0
    );
    if (!empty($_VIDEOS_CONF['seo_catalogue_index'])) {
        $catalogueHeader .= $faqService->structuredData($faqItems);
    }
}
$catalogueHeader .= "\n" . videos_catalogue_search_style();
$pageTitle = $isLocalSearch
    ? sprintf($LANG_VIDEOS['catalogue_search_page_title'], $searchQuery) . ' - ' . $publicTitle
    : $publicTitle;
if (!$isLocalSearch && $page > 1) {
    $pageTitle .= ' – Page ' . $page;
}
echo COM_createHTMLDocument(
    $html,
    array(
        'pagetitle' => $pageTitle,
        'headercode' => $catalogueHeader
    )
);

/**
 * Return catalogue data from local persistent state only.
 *
 * Public requests must never trigger provider traffic. External discovery and
 * refresh work belongs to explicit administration/maintenance actions.
 */
function videos_public_search($bootstrap, $query, $configuration)
{
    $cache = new Videos_Cache($bootstrap->getStore());
    $parameters = videos_build_public_search_parameters($configuration);
    $context = array(
        'query' => $query,
        'parameters' => $parameters
    );
    $key = $cache->searchKey($context);

    $cached = $cache->getSearch($key, true);
    if ($cached === false) {
        $cached = $cache->findCompatibleSearch($context, 500);
    }
    if ($cached !== false &&
        isset($cached['data']['result']) &&
        is_array($cached['data']['result'])) {
        $result = $cached['data']['result'];
        if (!isset($result['videos']) || !is_array($result['videos'])) {
            $result['videos'] = array();
        }
        $result['video_ids'] = array_keys($result['videos']);
        $result['query'] = $query;
        $result['cache_key'] = $key;
        $result['local_only'] = true;
        return $result;
    }

    if (!empty($configuration['discovery_enabled'])) {
        $reservoir = new Videos_DiscoveryReservoir(
            $bootstrap->getStore(),
            $cache
        );
        $videos = $reservoir->videos($configuration);
        if (is_array($videos) && count($videos) > 0) {
            return array(
                'video_ids' => array_keys($videos),
                'videos' => $videos,
                'channels' => array(),
                'query' => $query,
                'cache_key' => '',
                'local_only' => true,
                'reservoir_fallback' => true
            );
        }
    }

    return false;
}

function videos_build_public_search_parameters($configuration)
{
    return array(
        'max_results' => isset($configuration['youtube_max_results'])
            ? $configuration['youtube_max_results'] : 20,
        'order' => 'relevance',
        'safe_search' => isset($configuration['youtube_safe_search'])
            ? $configuration['youtube_safe_search'] : 'moderate',
        'language' => isset($configuration['language'])
            ? $configuration['language'] : 'fr',
        'region' => isset($configuration['region'])
            ? $configuration['region'] : 'FR',
        'published_after' => '',
        'category_id' => '',
        'channel_id' => '',
        'daily_search_limit' => isset(
            $configuration['youtube_daily_search_limit']
        ) ? $configuration['youtube_daily_search_limit'] : 20,
        'cache_ttl' => isset($configuration['search_cache_ttl'])
            ? $configuration['search_cache_ttl'] : 86400,
        'video_cache_ttl' => isset($configuration['video_cache_ttl'])
            ? $configuration['video_cache_ttl'] : 86400,
        'channel_cache_ttl' => isset($configuration['channel_cache_ttl'])
            ? $configuration['channel_cache_ttl'] : 604800,
        'availability_cache_ttl' => isset(
            $configuration['availability_cache_ttl']
        ) ? $configuration['availability_cache_ttl'] : 86400,
        'blocked_videos' => isset($configuration['blocked_videos'])
            ? $configuration['blocked_videos'] : '',
        'blocked_channels' => isset($configuration['blocked_channels'])
            ? $configuration['blocked_channels'] : '',
        'allowed_channels' => isset($configuration['allowed_channels'])
            ? $configuration['allowed_channels'] : '',
        'minimum_duration' => 0,
        'maximum_duration' => 0,
        'exclude_short_videos' => !empty($configuration['exclude_short_videos'])
            ? 1 : 0,
        'short_filter_mode' => isset($configuration['short_filter_mode'])
            ? $configuration['short_filter_mode'] : 'probable',
        'short_max_duration' => isset($configuration['short_max_duration'])
            ? $configuration['short_max_duration'] : 180
    );
}

function videos_catalogue_search_style()
{
    return '<style>'
        . '.videos-catalogue-search{margin:0 0 1.25rem;padding:1rem;border:1px solid rgba(127,127,127,.28);border-radius:.55rem;background:rgba(127,127,127,.045)}'
        . '.videos-catalogue-search label{display:block;margin-bottom:.45rem;font-weight:600}'
        . '.videos-catalogue-search>div{display:flex;gap:.5rem;align-items:stretch}'
        . '.videos-catalogue-search input{flex:1 1 20rem;min-width:0;padding:.65rem .75rem;border:1px solid rgba(127,127,127,.45);border-radius:.35rem;background:transparent;color:inherit}'
        . '.videos-catalogue-search button{padding:.65rem 1rem;border:1px solid rgba(127,127,127,.45);border-radius:.35rem;cursor:pointer}'
        . '.videos-catalogue-search p,.videos-search-summary{font-size:.88rem;line-height:1.4}'
        . '.videos-catalogue-search p{margin:.55rem 0 0;opacity:.75}'
        . '.videos-search-summary{margin:0 0 1rem;padding:.7rem .85rem;background:rgba(127,127,127,.08);border-radius:.4rem}'
        . '@media(max-width:520px){.videos-catalogue-search>div{flex-direction:column}.videos-catalogue-search input,.videos-catalogue-search button{width:100%;box-sizing:border-box}}'
        . '</style>';
}
